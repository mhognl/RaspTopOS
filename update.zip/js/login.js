function validate() {

	var u=document.getElementById("usr").value;
	var p=document.getElementById("pwd").value;
	
	if (u=="admin" || p=="admin") {
		location.href="/user-sodifjoiwejroijoijasoidjfiopzxjcv29384j98zj98jzxc98vj";
	}
}