function val() {
	if (document.getElementById("val").value=="wipemydata") {
		location.href="recovery_confirmed.html";
	}
}